function showHorarioTable() {
    const table = document.getElementById("horario-table");
    if (table.style.display === "none") {
        table.style.display = "table";
    } else {
        table.style.display = "none";
    }
}
