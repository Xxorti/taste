function showNotasTable() {
    const table = document.getElementById("notas-table");
    if (table.style.display === "none") {
        table.style.display = "table";
    } else {
        table.style.display = "none";
    }
}
