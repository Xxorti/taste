function selectTab(tabId) {
    const tabs = document.querySelectorAll('.tab');
    const contents = document.querySelectorAll('.content');

    tabs.forEach(tab => {
        tab.style.backgroundColor = tab.id === tabId ? '#007bff' : '#fff';
        tab.style.color = tab.id === tabId ? '#fff' : '#007bff';
    });

    contents.forEach(content => {
        content.style.display = content.id === tabId + '-login' ? 'block' : 'none';
    });
}
