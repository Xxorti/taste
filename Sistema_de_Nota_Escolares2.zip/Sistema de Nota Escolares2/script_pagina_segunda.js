function redirectTo(page) {
    window.location.href = page;
}