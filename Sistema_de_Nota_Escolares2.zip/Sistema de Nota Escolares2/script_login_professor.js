function validateLogin() {
    // Obter dados do formulário
    const username = document.getElementById("login-username").value;
    const password = document.getElementById("login-password").value;

    // Simular validação do login no backend para professores
    FakeDB.validateProfessor(username, password, function(response) {
        if (response.success) {
            alert("Login bem-sucedido!");
            // Redirecionar o professor para a página do professor
            window.location.href = "pagina_segunda.html";
        } else {
            alert("Usuário ou senha inválidos. Tente novamente.");
        }
    });
}

// Exemplo fictício de uma biblioteca para interagir com um banco de dados simulado
var FakeDB = {
    professors: [
        { username: "escolacostasilva@gmail.com", password: "123456" },
        { username: "caua20", password: "123456" },
        // Adicione mais professores conforme necessário
    ],
    
    validateProfessor: function(username, password, callback) {
        // Simular lógica de validação de professor no backend
        // (substitua isso com sua lógica real de backend)
        setTimeout(function() {
            const professor = FakeDB.professors.find(p => p.username === username && p.password === password);
            callback({ success: !!professor });
        }, 1000);
    }
    // Adicione mais lógica conforme necessário para recuperar dados do professor, etc.
};
