function showCalendarioTable() {
    const table = document.getElementById("calendario-table");
    if (table.style.display === "none") {
        table.style.display = "table";
    } else {
        table.style.display = "none";
    }
}
