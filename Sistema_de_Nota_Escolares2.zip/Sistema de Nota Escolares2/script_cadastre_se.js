// Este é um exemplo fictício usando uma biblioteca chamada FakeDB
// Você precisará substituir isso por uma lógica real de interação com o seu backend

function registerUser() {
    // Obter dados do formulário
    const username = document.getElementById("signup-username").value;
    const email = document.getElementById("signup-email").value;
    const password = document.getElementById("signup-password").value;

    // Simular envio de dados para o backend
    FakeDB.saveUser(username, email, password, function(response) {
        if (response.success) {
            alert("Cadastro realizado com sucesso!");
            // Redirecionar o usuário para a página de login
            window.location.href = "login.html";
        } else {
            alert("Erro ao cadastrar. Tente novamente.");
        }
    });
}

// Exemplo fictício de uma biblioteca para interagir com um banco de dados simulado
var FakeDB = {
    users: [],
    
    saveUser: function(username, email, password, callback) {
        // Simular lógica de salvar usuário no banco de dados
        // (substitua isso com sua lógica real de backend)
        setTimeout(function() {
            FakeDB.users.push({ username, email, password });
            callback({ success: true });
        }, 1000);
    }
    // Adicione mais lógica conforme necessário para validar usuários, etc.
};
